import React,{ useState } from "react";
import './ExpenceForm.css'

const ExpenceForm = (props) => {

    const [enteredTitle , setEnteredTitle] = useState('');
    const [enteredAmount , setEnteredAmount] = useState('');
    const [enteredDate , setEnteredDate] = useState('');



    const titleChangeHandler = (event) => {
        setEnteredTitle(event.target.value);
    };
    const amountChangeHandler = (event) => {
        setEnteredAmount(event.target.value);
    };
    const dateChangeHandler = (event) => {
        setEnteredDate(event.target.value);
    };

   const submitHandler = (event) => {
          event.preventDefault();

          const expenceData = {
            title: enteredTitle,
            amount: enteredAmount,
            date: new Date(enteredDate)
          }
         
          props.onSaveExpenceData(expenceData);

          setEnteredTitle('');
          setEnteredAmount('');
          setEnteredDate ('');
   };

    return(
        <form onSubmit={submitHandler}>
        <div className="new-expence__controls">
            <div className="new-expence__control">
               <label>Title</label>
               <input type="text" value={enteredTitle} onChange={titleChangeHandler}></input>
            </div>

            <div className="new-expence__control">
               <label>Amount</label>
               <input type="number" value={enteredAmount} onChange={amountChangeHandler} min="0.01" step="0.01"></input>
            </div>

            <div className="new-expence__control">
               <label>Date</label>
               <input type="date" value={enteredDate} onChange={dateChangeHandler}></input>
            </div>
 
        </div>
        <div className="new-expence__actions">
         <button type="submit" >Add Expense</button>
        </div>
        </form>
    );
}

export default ExpenceForm;