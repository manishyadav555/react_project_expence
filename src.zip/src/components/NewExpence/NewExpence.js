import React from "react";
import ExpenceForm from "./ExpenceForm";
import './NewExpence.css'


const NewExpence = (props) => {

        const saveExpenceDataHandler = (enteredExpenceData) =>{
                const expenceData = {
                        ...enteredExpenceData,
                        id:Math.random().toString()
                }
 
                props.onAddExpance(expenceData);

                console.log(expenceData);

        };

     return(

        <div className="new-expence">
                
                  <ExpenceForm onSaveExpenceData={saveExpenceDataHandler}/>
               
        </div>

     );
}

export default NewExpence;