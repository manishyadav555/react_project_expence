import React from 'react';
import './Expences.css';
import ExpenceItem from './ExpenceItem';
const Expences= (props) => {

   return (
    <div className='expenses'>
       {
            props.item.map(
                  expence => (
                        <ExpenceItem
                        date={expence.date}
                        title={expence.title} 
                        amount={expence.amount} />
                  )
            )
       }

         
    </div>
   );


}

export default Expences;