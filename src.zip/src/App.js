import React, {useState} from 'react';
import Expences from './components/Expenses/Expences';
import NewExpence from './components/NewExpence/NewExpence';

let DUMMY_EXPENCE = [
  {
    id:'e1',
    title:'schhol Fee',
    amount:250,
    date:new Date(2014, 7, 6)
  },

  {
    id:'e2',
    title:'hous Fee',
    amount:253,
    date:new Date(2014, 7, 6)
  },

  {
    id:'e3',
    title:'food Fee',
    amount:1120,
    date:new Date(2004, 7, 6)
  }
];


const App = () => {
    
   const [expence, setExpenses] = useState(DUMMY_EXPENCE);
  
  
     
  const addExpenceHandler =(expences) => {
     const updatedExpence = [expences, ...expence];
     setExpenses(updatedExpence);
  };





    return (
    <div>
      <NewExpence onAddExpance={addExpenceHandler} />
        <Expences item={expence} />
     </div>
  );
  
}

export default App;
